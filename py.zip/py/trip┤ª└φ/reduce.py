#!/usr/bin/python
import sys


for line in sys.stdin:
    line = line.strip()
    #word = line.split(' ')


    print line